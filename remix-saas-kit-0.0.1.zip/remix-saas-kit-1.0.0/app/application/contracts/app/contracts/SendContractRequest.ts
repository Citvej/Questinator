export interface SendContractRequest {
  emails: string[];
}
