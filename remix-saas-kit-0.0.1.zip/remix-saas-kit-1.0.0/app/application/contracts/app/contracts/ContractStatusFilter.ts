export enum ContractStatusFilter {
  PENDING,
  SIGNED,
  ARCHIVED,
  ALL,
}
