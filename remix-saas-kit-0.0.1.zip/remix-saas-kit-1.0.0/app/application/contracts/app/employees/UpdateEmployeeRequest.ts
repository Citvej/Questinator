export interface UpdateEmployeeRequest {
  firstName: string;
  lastName: string;
  email: string;
}
