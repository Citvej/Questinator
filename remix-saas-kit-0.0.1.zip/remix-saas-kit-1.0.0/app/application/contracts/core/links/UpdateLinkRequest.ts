export interface UpdateLinkRequest {
  accepted: boolean;
}
