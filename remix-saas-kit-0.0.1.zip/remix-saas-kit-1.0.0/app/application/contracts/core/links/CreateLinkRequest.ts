export interface CreateLinkRequest {
  email: string;
  workspaceName: string;
  asProvider: boolean;
}
