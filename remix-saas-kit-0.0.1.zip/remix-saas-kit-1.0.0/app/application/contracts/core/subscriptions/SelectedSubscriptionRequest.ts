export interface SelectedSubscriptionRequest {
  subscriptionPriceId?: string;
  subscriptionCardToken?: string;
  subscriptionCoupon?: string;
}
