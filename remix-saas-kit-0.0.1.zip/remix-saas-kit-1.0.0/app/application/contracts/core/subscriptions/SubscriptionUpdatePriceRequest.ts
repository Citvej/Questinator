export interface SubscriptionUpdatePriceRequest {
  id: string;
  active: boolean;
}
