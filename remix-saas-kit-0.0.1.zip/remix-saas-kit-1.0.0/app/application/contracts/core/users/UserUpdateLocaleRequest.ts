export interface UserUpdateLocaleRequest {
  locale: string;
}
