export interface UserUpdateRequest {
  firstName: string;
  lastName: string;
  phone: string;
}
