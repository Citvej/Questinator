export interface UserUpdateAvatarRequest {
  avatar: string;
}
