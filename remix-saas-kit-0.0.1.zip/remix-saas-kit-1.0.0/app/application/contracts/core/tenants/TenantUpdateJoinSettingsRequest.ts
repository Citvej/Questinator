export interface TenantUpdateJoinSettingsRequest {
  enableLink: boolean;
  resetLink: boolean;
  enablePublicUrl: boolean;
  requireAcceptance: boolean;
}
