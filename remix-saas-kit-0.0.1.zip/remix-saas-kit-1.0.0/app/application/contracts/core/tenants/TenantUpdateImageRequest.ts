export interface TenantUpdateImageRequest {
  type: string;
  icon: string;
  logo: string;
  logoDarkmode: string;
}
