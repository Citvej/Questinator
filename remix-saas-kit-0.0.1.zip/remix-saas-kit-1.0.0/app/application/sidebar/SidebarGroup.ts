import { SideBarItem } from "./SidebarItem";

export interface SidebarGroup {
  title: string;
  items: SideBarItem[];
}
