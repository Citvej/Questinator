export interface Month {
  value: number;
  title: string;
  shortTitle: string;
}
