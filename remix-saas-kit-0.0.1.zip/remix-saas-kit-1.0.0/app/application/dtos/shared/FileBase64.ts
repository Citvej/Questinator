export interface FileBase64 {
  file: File;
  base64: any;
}
