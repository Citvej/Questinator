import { SubscriptionCardDto } from "./SubscriptionCardDto";

export interface SubscriptionPaymentMethodDto {
  card: SubscriptionCardDto;
}
