export interface SubscriptionCustomerDto {
  id: string;
  email: string;
  name: string;
  description: string;
  phone: string;
  currency: string;
  created: Date;
}
