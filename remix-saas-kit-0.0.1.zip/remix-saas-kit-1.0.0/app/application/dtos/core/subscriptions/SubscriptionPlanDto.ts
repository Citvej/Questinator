export interface SubscriptionPlanDto {
  trialPeriodDays: number;
  trialStart?: string;
  trialEnd?: string;
}
