export interface SubscriptionCardDto {
  brand: string;
  expiryMonth: number;
  expiryYear: number;
  lastFourDigits: string;
  expiryDate: Date;
}
