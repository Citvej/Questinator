import { EntityDto } from "../EntityDto";

// tslint:disable-next-line: no-empty-interface
export type MasterEntityDto = EntityDto
