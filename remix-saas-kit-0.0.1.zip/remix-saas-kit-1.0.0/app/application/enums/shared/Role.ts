export enum Role {
  ADMINISTRATOR,
  MEMBER,
  GUEST,
}
