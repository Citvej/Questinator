export enum ApplicationLayout {
  SIDEBAR,
  STACKED,
}
