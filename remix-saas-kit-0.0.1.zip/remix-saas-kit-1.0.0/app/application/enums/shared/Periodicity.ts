export enum Periodicity {
  ONCE,
  MONTHLY,
  BIMONTHLY,
  QUARTERLY,
  YEARLY,
}
