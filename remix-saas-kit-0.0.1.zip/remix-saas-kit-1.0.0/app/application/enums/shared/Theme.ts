export enum Theme {
  LIGHT,
  DARK,
}
