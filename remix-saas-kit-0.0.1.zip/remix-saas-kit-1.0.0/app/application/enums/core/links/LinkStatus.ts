export enum LinkStatus {
  PENDING,
  LINKED,
  REJECTED,
}
