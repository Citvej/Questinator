export enum SubscriptionPriceType {
  ONE_TIME,
  RECURRING,
}
