export enum SubscriptionBillingPeriod {
  ONCE,
  DAILY,
  WEEKLY,
  MONTHLY,
  YEARLY,
}
