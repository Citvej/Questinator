export enum UserLoginType {
  PASSWORD,
}
