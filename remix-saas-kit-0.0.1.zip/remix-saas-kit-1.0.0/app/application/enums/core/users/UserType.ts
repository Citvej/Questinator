export enum UserType {
  Admin,
  Tenant,
}
