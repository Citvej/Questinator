export enum WorkspaceType {
  PRIVATE,
  PUBLIC,
}
