export enum TenantUserRole {
  OWNER,
  ADMIN,
  MEMBER,
  GUEST,
}
