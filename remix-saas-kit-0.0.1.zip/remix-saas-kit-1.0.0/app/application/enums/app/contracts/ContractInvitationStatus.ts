export enum ContractInvitationStatus {
  PENDING,
  REJECTED,
  ACCEPTED,
}
