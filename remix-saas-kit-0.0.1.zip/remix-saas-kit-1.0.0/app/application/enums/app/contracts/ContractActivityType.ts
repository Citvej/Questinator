export enum ContractActivityType {
  CREATED,
  UPDATED,
}
