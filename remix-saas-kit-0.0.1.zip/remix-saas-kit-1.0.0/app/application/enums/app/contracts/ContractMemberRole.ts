export enum ContractMemberRole {
  SIGNATORY,
  SPECTATOR,
}
