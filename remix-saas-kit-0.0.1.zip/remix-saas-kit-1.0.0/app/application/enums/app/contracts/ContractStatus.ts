export enum ContractStatus {
  PENDING,
  SIGNED,
  ARCHIVED,
}
