export default [
  {
    lang: "en",
    name: "en",
    flag: "us",
    lang_short: "en",
  },
  {
    lang: "es",
    name: "es",
    flag: "mx",
    lang_short: "es",
  },
];
