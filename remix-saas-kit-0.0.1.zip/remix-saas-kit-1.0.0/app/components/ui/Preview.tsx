export default function Preview() {
  return <div className="space-y-2 w-full">{/*  */}</div>;
}
